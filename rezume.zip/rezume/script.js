const btn = document.getElementById('saveBtn');
if (btn) {
    btn.addEventListener('click', function() {
        const inputs = {
            username: document.getElementById('nameInput').value,
            job: document.getElementById('jobInput').value,
            address: document.getElementById('addressInput').value,
            email: document.getElementById('emailInput').value,
            phone: document.getElementById('phoneInput').value,
            dob: document.getElementById('dobInput').value,
            skills: document.getElementById('skillsInput').value,
            languages: document.getElementById('languagesInput').value,
            hobbies: document.getElementById('hobbiesInput').value,
            startDate: document.getElementById('startDateInput').value,
            endDate: document.getElementById('endDateInput').value,
            positionHeld: document.getElementById('positionHeldInput').value,
            company: document.getElementById('companyInput').value,
            jobRole: document.getElementById('jobRoleInput').value,
            eduStartDate: document.getElementById('eduStartDateInput').value,
            eduEndDate: document.getElementById('eduEndDateInput').value,
            degree: document.getElementById('degreeInput').value,
            institution: document.getElementById('institutionInput').value,
            courseDescription: document.getElementById('courseDescriptionInput').value
        };

        Object.keys(inputs).forEach(key => localStorage.setItem(key, inputs[key]));

        window.location.href = 'sahifa2.html'; 
    });
}
const nameElement = document.getElementById('name'),
    jobElement = document.getElementById('job'),
    addressElement = document.getElementById('address'),
    emailElement = document.getElementById('email'),
    phoneElement = document.getElementById('phone'),
    dobElement = document.getElementById('dob'),
    skillsList = document.getElementById('skillsList'),
    languagesList = document.getElementById('languagesList'),
    hobbiesList = document.getElementById('hobbiesList'),
    startDateElement = document.getElementById('startDate'),
    endDateElement = document.getElementById('endDate'),
    positionElement = document.getElementById('position'),
    companyElement = document.getElementById('company'),
    jobRoleElement = document.getElementById('jobRole'),
    eduStartDateElement = document.getElementById('eduStartDate'),
    eduEndDateElement = document.getElementById('eduEndDate'),
    degreeElement = document.getElementById('degree'),
    institutionElement = document.getElementById('institution'),
    courseDescriptionElement = document.getElementById('courseDescription');

function setElementText(element, key) {
    const storedValue = localStorage.getItem(key);
    if (storedValue && element) {
        element.textContent = storedValue;
    } else if (element) {
        element.textContent = `No ${key} found`;
        
    }
}


setElementText(nameElement, 'username');
setElementText(jobElement, 'job');
setElementText(addressElement, 'address');
setElementText(emailElement, 'email');
setElementText(phoneElement, 'phone');
setElementText(dobElement, 'dob');
setElementText(skillsList, 'skills');
setElementText(languagesList, 'languages');
setElementText(hobbiesList, 'hobbies');
setElementText(startDateElement, 'startDate');
setElementText(endDateElement, 'endDate');
setElementText(positionElement, 'positionHeld');
setElementText(companyElement, 'company');
setElementText(jobRoleElement, 'jobRole');
setElementText(eduStartDateElement, 'eduStartDate');
setElementText(eduEndDateElement, 'eduEndDate');
setElementText(degreeElement, 'degree');
setElementText(institutionElement, 'institution');
setElementText(courseDescriptionElement, 'courseDescription');

const AddTable=document.getElementById('AddTable'),
ParentsTable=document.getElementById('ParentsTable'),
DeleteTable=document.getElementById('DeleteTable')
AddTable.addEventListener('click',MyFunction)
 elements=`<tr>
            <td><input type="text"></td>
            <td><input type="text"></td>
            <td><input type="text"></td>
            <td><input type="text"></td>
            <td><input type="text"></td>
          </tr>`
function MyFunction(){
    ParentsTable.innerHTML+=elements
      console.log(AddTable); 
console.log(ParentsTable);
}
MyFunction();

DeleteTable.addEventListener('click', deleteFunction)
function deleteFunction(){
    let tr=ParentsTable.getElementsByTagName('tr')
    if (tr.length > 0) {                           
      let lastRow = tr[tr.length - 1];           
      lastRow.remove();  
    }
}

deleteFunction()

const saveBtnClass=document.getElementsByClassName('saveBtn')
let Parents=document.getElementById('Parents')
saveBtnClass.addEventListener('click',tableFunction)
function tableFunction(){
    if(tr.length>2)
    Parents.textContent+=ParentsTable
}
tableFunction()

function saveTable() {
    const table = document.getElementById('ParentsTable').outerHTML;
    localStorage.setItem('tableData', table);
    window.location.href = 'sahifa2.html'; 
}


function loadTable() {
    const tableData = localStorage.getItem('tableData');
    if (tableData) {
       
        document.getElementById('Parents').innerHTML = tableData;
    } else {
        document.getElementById('Parents').innerHTML = '<p>No table data found</p>';
    }
}
